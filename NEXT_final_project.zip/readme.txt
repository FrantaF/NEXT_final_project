 
This is Next Academy 2018 July Batch, Group 2, Final Project