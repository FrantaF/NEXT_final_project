class SubscriptionsController < ApplicationController

   def pricing_tables
   end



end
