class StaticController < ApplicationController
end
