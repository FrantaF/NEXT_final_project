class DustbinStat < ApplicationRecord
    def update
    end
end
