class Raspberrypi < ApplicationRecord
    
end
