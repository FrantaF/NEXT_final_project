class FillLevel < ApplicationRecord
end
