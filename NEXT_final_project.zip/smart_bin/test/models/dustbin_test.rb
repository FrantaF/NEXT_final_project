require 'test_helper'

class DustbinTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
